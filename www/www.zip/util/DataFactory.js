﻿(function () {

    'use strict';

    angular
        .module('foneClub')
        .factory('DataFactory', DataFactory);

    DataFactory.$inject = [];

    function DataFactory() {

        var data = {};

        return data;

    }

})();
