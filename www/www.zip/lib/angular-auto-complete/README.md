# AngularJS auto-complete

`npm install angular-auto-complete`

`bower install angular-auto-complete`

#### Requirements

* AngularJS v1.5.0+
* AngularJS Sanitize


<b>Demo:</b> http://demo.vickram.me/angular-auto-complete

<a href="https://github.com/vickramravichandran/angular-auto-complete/archive/demo.zip">Download Demo zip</a>
